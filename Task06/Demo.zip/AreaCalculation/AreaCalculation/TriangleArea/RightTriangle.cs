﻿using System;

namespace TriangleArea
{
	internal class RightTriangle
	{
		private double _cathetusOne;
		private double _cathetusTwo;
		private double _hypotenuse;

		public RightTriangle(double sideOne, double sideTwo, double sideThree)
		{
			Hypotenuse = sideOne;
			CathetusOne = sideTwo;
			CathetusTwo = sideThree;

			if (sideTwo > Hypotenuse)
			{
				Hypotenuse = sideTwo;
				CathetusOne = sideOne;
			}

			if (sideThree > Hypotenuse)
			{
				Hypotenuse = sideThree;
				CathetusTwo = sideTwo;
			}

			if (Math.Abs(Hypotenuse * Hypotenuse - (CathetusOne * CathetusOne + CathetusTwo * CathetusTwo))
					> Double.Epsilon)
				throw new ArithmeticException("Unable to calc right triangle area. Provided triangle is not right.");
		}

		public double CathetusOne
		{
			get
			{
				return _cathetusOne;
			}

			private set
			{
				CheckLength(value);
				_cathetusOne = value;
			}
		}

		public double CathetusTwo
		{
			get
			{
				return _cathetusTwo;
			}

			private set
			{
				CheckLength(value);
				_cathetusTwo = value;
			}
		}

		public double Hypotenuse
		{
			get
			{
				return _hypotenuse;
			}

			private set
			{
				CheckLength(value);
				_hypotenuse = value;
			}
		}

		public double CalcArea()
		{
			double area = CathetusOne*CathetusTwo/2;
			if (double.IsInfinity(area))
				throw new OverflowException("Unable to calc right triangle area. Result is too long.");
			return area;
		}

		private static void CheckLength(double value)
		{
			if (value <= 0)
				throw new ArithmeticException("Unable to calc right triangle area. Side length must be positive.");
		}
	}
}
