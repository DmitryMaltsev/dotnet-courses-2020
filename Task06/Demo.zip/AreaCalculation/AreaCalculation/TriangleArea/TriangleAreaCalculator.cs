namespace TriangleArea
{
	/// <summary>
	/// Contains methods for calculating the area of the right triangle
	/// </summary>
	public static class TriangleAreaCalculator
	{
		/// <summary>
		/// Calculates the area of right triangle by its sides length
		/// </summary>
		/// <param name="sideOne">length of the first side</param>
		/// <param name="sideTwo">length of the second side</param>
		/// <param name="sideThree">length of the third side</param>
		/// <returns>Area of triangle</returns>
		public static double CalcRightTriangleArea(double sideOne, double sideTwo, double sideThree)
		{
			RightTriangle rightTriangle = new RightTriangle(sideOne, sideTwo, sideThree);
			return rightTriangle.CalcArea();
		}
	}
}